package com.example.tictactoe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class Main2Activity extends AppCompatActivity implements View.OnClickListener {
    Button[][] button = new Button[3][3];
    boolean turnp1 = true;
    int count=0;
    int pointp1=0,pointp2=0;
    TextView p1,p2;
    String s1,s2;
    int num=0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent=getIntent();
        s1=intent.getStringExtra("s1");
        s2=intent.getStringExtra("s2");
        p1 = (TextView)findViewById(R.id.textView1);
        p2 = (TextView)findViewById(R.id.textView2);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                String buttonID = "b" + i + j;
                int resID=getResources().getIdentifier(buttonID, "id", getPackageName());
                button[i][j]=findViewById(resID);
                button[i][j].setOnClickListener(this);
            }
        }
        p1.setText(s1+": "+pointp1+" ");
        p2.setText(s2+": "+pointp2+" ");
        Button buttonReset = findViewById(R.id.button);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    @Override
    public void onClick(View v)
    {
        if (((Button) v).getText().toString().equals("")==false)
            return;
        if (turnp1)
        {
            ((Button) v).setText(" ");
            ((Button) v).setBackgroundResource(R.drawable.cross);
        }
        else
            {
            ((Button) v).setText("  ");
            ((Button) v).setBackgroundResource(R.drawable.zero);
            }
        count++;

        if (checkForWin())
        {
            if(turnp1)
                p1Wins();
            else
                p2Wins();
        }
        else if(count ==9 )
            draw();
        else
           turnp1=!turnp1;

    }

    private boolean checkForWin(){
        String[][] field = new String[3][3];

        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                field[i][j] = button[i][j].getText().toString();

            }
        }
        for(int i=0;i<3;i++) {
            if (field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])
                    && !field[i][0].equals("")) {
                return true;
            }
        }
        for(int i=0;i<3;i++) {
            if (field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i])
                    && !field[0][i].equals("")) {
                return true;
            }
        }
        if (field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])
                && !field[0][0].equals("")) {
            return true;

        }

        if (field[0][2].equals(field[1][1])
                && field[0][2].equals(field[2][0])
                && !field[0][2].equals("")){
            return true;
        }
        return false;
    }

    private void p1Wins()
    {
        pointp1++;
        Toast.makeText( this, s1+" wins!", Toast.LENGTH_SHORT).show();
        updatePoints();
        resetBoard();
    }

    private void p2Wins()
    {
        pointp2++;
        Toast.makeText(this, s2+" wins!", Toast.LENGTH_SHORT).show();
        updatePoints();
        resetBoard();
    }

    private void draw()
    {
        Toast.makeText( this, "Draw!",Toast.LENGTH_SHORT).show();
        resetBoard();
    }

    private void updatePoints()
    {
        p1.setText(s1+": "+pointp1+" ");
        p2.setText(s2+": "+pointp2+" ");
    }

    private void resetBoard()
    {
        for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
        {
            button[i][j].setText("");
            button[i][j].setBackgroundResource(R.drawable.tac);
        }
        count=0;
        turnp1=true;
    }

    private void resetGame()
    {
        pointp1=0;
        pointp2=0;
        updatePoints();
        resetBoard();
    }
}
